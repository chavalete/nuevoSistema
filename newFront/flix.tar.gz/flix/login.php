<?php
session_start();
if(!empty($_GET['crDestruir'])){
    session_destroy();
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>LIMON</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <link type="text/css" rel="stylesheet" href="css/login.css" />
        <link type="text/css" rel="stylesheet" href="css/msgBoxLight.css" />
        <script src="js/jQuery.min-1.8.3.js" type="text/javascript"></script>
        <script src="js/jquery.msgBox.js" type="text/javascript"></script>
        <script src="js/logIn.js" type="text/javascript"></script>
    </head>
    <body>
       <div class="login-cuadro">
            <div class="login-contenedor">
                <form class="form-login" >
                    USUARIO:<br /><input id="user" type="text" name="usuario" value=""><br />
                    CONTRASE&Ntilde;A:<br /><input id="pass" type="password" name="psw" value="">
                    SUCURSAL:<br />
                    <select name="sucursal" id="sucursal">
                        <option value="2">Moreno</option>
                        <option value="3">Rosas</option>
                        <option value="4">Limoneta</option>
                    </select>
                    <input type="button" name="Ingresar" value="INGRESAR" class="login-btn" />
                </form>
            </div>
       </div>
    </body>
</html>
